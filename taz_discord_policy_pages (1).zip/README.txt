TAZ DISCORD APPLICATION — POLICY PAGES

Files:
- terms.html
- privacy.html

PUBLISH WITH GITHUB PAGES
1. Sign in at https://github.com/
2. Create a NEW PUBLIC repository, for example: taz-legal-pages
3. Upload terms.html and privacy.html to the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish the site.
8. Your URLs will look like:
   https://YOUR-GITHUB-USERNAME.github.io/taz-legal-pages/terms.html
   https://YOUR-GITHUB-USERNAME.github.io/taz-legal-pages/privacy.html

DISCORD DEVELOPER PORTAL
1. Open your app > General Information.
2. Put the full terms.html URL in Terms of Service URL.
3. Put the full privacy.html URL in Privacy Policy URL.
4. Save changes.

IMPORTANT
The Privacy Policy is a starter template. It assumes temporary processing only,
with no persistent database or retained command logs. Do not publish that claim
unless it matches the bot's actual code and hosting. If the bot stores data or
uses logs, analytics, databases, or external providers, update the policy first.
Do not put bot tokens or client secrets in this repository.
